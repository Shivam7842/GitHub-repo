<?php

$insert = false;
$servername = "localhost";
$username = "root";
$password = "";
$database ="avaegtis";

$conn = mysqli_connect($servername,$username,$password,$database);
// if(!$conn)
// {
//   die("sorry we failed to connect".mysqli_connect_error());
// }

// $sql = "SELECT english, hindi, math, history, science  FROM `record`";
// $result = mysqli_query($conn, $sql);

//   $english = $_POST["english"];
//   $hindi = $_POST["hindi"];
//   $math = $_POST["math"];
//   $history = $_POST["history"];
//   $geography = $_POST["geography"];
//   $science = $_POST["science"];
//   $sum = $english + $hindi + $math + $science + $history + $geography ;
//   $percentage = $sum / 6 ;
//   echo $percentage;


?>


<!DOCTYPE html>
<html>
    <head>
        <body>
            <table>
            <div class="table" id="mytable">
                <thead>
                    <tr>
                        <th scope="col">sno</th>
                        <th scope="col">Student ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Class</th>
                        <th scope="col">Email</th>
                        <th scope="col">English</th>
                        <th scope="col">Hindi</th>
                        <th scope="col">Math</th>
                        <th scope="col">Science</th>
                        <th scope="col">History</th>
                        <th scope="col">Geography</th>
                        <th scope="col">Average</th>
                        <th scope="col">Grade</th>
                        <th scope="col">Remarks</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                        $sql = "SELECT * FROM `record`";
                        $result = mysqli_query($conn, $sql);                    
                        $sno = 1;
                        while($row = mysqli_fetch_assoc($result))
                        {
                          
                          echo "<tr>
                          <th scope='row'>".$sno."</th>
                          <td>". $row['student_id']."</td>
                          <td>". $row['fname']."</td>
                          <td>". $row['lname']."</td>
                          <td>". $row['class']."</td>
                          <td>". $row['email']."</td>
                          <td>". $row['english']."</td>
                          <td>". $row['hindi']."</td>
                          <td>". $row['math']."</td>
                          <td>". $row['science']."</td>
                          <td>". $row['history']."</td>
                          <td>". $row['geography']."</td>
                          <td>". $row['average']." %"."</td>
                          <td>". $row['grade']." %"."</td>
                          <td>". $row['remarks']."</td>
                          
                        </tr>";
                        $sno = $sno + 1;
                
                         
                        }
                    ?>
                </tbody>
            </div>
            </table>
            
        </body>
        
    </head>
</html>
<!-- <td>". ($row['english']+ $row['hindi']+$row['math']+$row['science']+$row['history']+$row['geography'])/6 ."</td> -->
