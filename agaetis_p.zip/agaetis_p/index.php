<?php

$insert = false;
$servername = "localhost";
$username = "root";
$password = "";
$database ="avaegtis";

$conn = mysqli_connect($servername,$username,$password,$database);

if(!$conn)
{
  die("sorry we failed to connect".mysqli_connect_error());
}
//echo $_SERVER['REQUEST_METHOD'] ;
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
  $student_id = $_POST["student_id"];
  $fname = $_POST["fname"];
  $lname = $_POST["lname"];
  $class = $_POST["class"];
  $email = $_POST["email"];
  $english = $_POST["english"];
  $hindi = $_POST["hindi"];
  $math = $_POST["math"];
  $science = $_POST["science"];
  $history = $_POST["history"];
  $geography = $_POST["geography"];
  $remarks = $_POST["remarks"];

  $total = ($english + $hindi + $math + $science + $history + $geography)/6;

  if($total >= 75){

    $grade = 'Distinction';

  }
elseif($total >= 60 OR $total <= 74){
  $grade = 'First Class';

}
elseif($total >= 33 OR $total <= 59 ){
  $grade = 'Pass';

}
else{
  $grade = 'Fail';

}


  $sql = "INSERT INTO `record` (`student_id`,`fname`,`lname`,`class`,`email`,`english`,`hindi`,`math`,`science`,`history`,`geography`,`average`,`grade`, `remarks`)
                VALUES ('$student_id','$fname','$lname','$class','$email','$english','$hindi','$math','$science','$history','$geography','$total','$grade','$remarks')";
  $result = mysqli_query($conn,$sql);

  if($result)
  {
    // echo "Data insert successfully<br>";
    $insert = true;
  }
  else{
    echo "Data was not insert successfully".mysqli_error($conn);
  }
  
}



?>


<!DOCTYPE html>
<html>
    <head>
        <title>Entry Form</title>
        <body>
            <h2>Student Entry Form</h2>
            <form name="entryForm" method="post" onsubmit="return validateForm()">
            <label for="student_id">Student ID*:</label>
            <input type="number" id="student_id" name="student_id" required><br><br>

            <label for="fname">First Name*:</label>
            <input type="text" id="fname" name="fname" required><br><br>

            <label for="lname">Last Name*:</label>
            <input type="text" id="lname" name="lname" required><br><br>

            <label for="class">Batch/Class*:</label>
            <input type="text" id="class" name="class" required><br><br>

            <label for="email">Email Address*:</label>
            <input type="email" id="email" name="email" required><br>

            <h3>Subjects</h3>
            <div class="row">
                <div class="col">
                    <label for="english">English:</label>
                    <input type="number" id="english" name="english" min="0" max="100" step="0.01">

                    <label for="hindi">Hindi:</label>
                    <input type="number" id="hindi" name="hindi" min="0" max="100" step="0.01"><br><br>

                    <label for="math">Math:</label>
                    <input type="number" id="math" name="math" min="0" max="100" step="0.01">

                    <label for="science">Science:</label>
                    <input type="number" id="science" name="science" min="0" max="100" step="0.01"><br><br>

                    <label for="history">History:</label>
                    <input type="number" id="history" name="history" min="0" max="100" step="0.01">

                    <label for="geography">Geography:</label>
                    <input type="number" id="geography" name="geography" min="0" max="100" step="0.01"><br><br>

                    <label for="remarks">Remarks:</label>
                    <input type="text-area" id="remarks" name="remarks" min="0" max="100" step="0.01"><br><br>
                </div>
            </div>

            <button class="btn btn-success" type="submit">submit</button>
            
            
    </a>
            
        </form>


        </body>





        <script>
		function validateForm() {
			// Get values from form
			var student_id = document.forms["entryForm"]["student_id"].value;
			var fname = document.forms["entryForm"]["fname"].value;
			var lname = document.forms["entryForm"]["lname"].value;
			var Class = document.forms["entryForm"]["class"].value;
			var email = document.forms["entryForm"]["email"].value;
			var english = document.forms["entryForm"]["english"].value;
			var hindi = document.forms["entryForm"]["hindi"].value;
			var math = document.forms["entryForm"]["math"].value;
			var science = document.forms["entryForm"]["science"].value;
			var history = document.forms["entryForm"]["history"].value;
			var geography = document.forms["entryForm"]["geography"].value;

			// Check for empty fields
			if (student_id == "" || fname == "" || lname == "" || Class == "" || email == "" || english == "" || hindi == "" || math == "" || science == "" || history == "" || geography == "") {
				alert("All fields are mandatory!");
				return false;
			}

			// Validate numeric fields
			if (isNaN(student_id) || isNaN(english) || isNaN(hindi) || isNaN(math) || isNaN(science) || isNaN(history) || isNaN(geography)) {
				alert("Numeric fields must contain numbers only!");
				return false;
			}

			// Validate email format
			var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
			if (!emailPattern.test(email)) {
				alert("Invalid email address!");
				return false;
			}

			// Validate text fields
			var namePattern = /^[A-Za-z]+$/;
			var batchPattern = /^[A-Za-z0-9]+$/;
			if (!namePattern.test(firstName) || !namePattern.test(lastName) || !batchPattern.test(batchClass)) {
				alert("Invalid input!");
				return false;
			}

			return true;
		}

        
	</script>
    </head>
</html>